class ToolPanel {
  static init(){
    
  }
}